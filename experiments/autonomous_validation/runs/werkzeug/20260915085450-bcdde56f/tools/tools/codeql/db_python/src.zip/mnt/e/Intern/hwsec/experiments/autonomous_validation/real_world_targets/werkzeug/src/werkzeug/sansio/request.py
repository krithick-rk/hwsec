from __future__ import annotations

import collections.abc as cabc
import typing as t
from datetime import datetime
from urllib.parse import parse_qsl

from ..datastructures import Accept
from ..datastructures import Authorization
from ..datastructures import ETags
from ..datastructures import Headers
from ..datastructures import HeaderSet
from ..datastructures import IfRange
from ..datastructures import ImmutableMultiDict
from ..datastructures import LanguageAccept
from ..datastructures import MIMEAccept
from ..datastructures import Range
from ..datastructures import RequestCacheControl
from ..http import parse_date
from ..http import parse_list_header
from ..http import parse_options_header
from ..http import SecFetchDest
from ..http import SecFetchMode
from ..http import SecFetchSite
from ..user_agent import _UserAgent
from ..utils import cached_property
from ..utils import header_property
from .http import parse_cookie
from .utils import get_content_length
from .utils import get_current_url
from .utils import get_host


class Request:
    """Represents the non-IO parts of a HTTP request, including the
    method, URL info, and headers.

    This class is not meant for general use. It should only be used when
    implementing WSGI, ASGI, or another HTTP application spec. Werkzeug
    provides a WSGI implementation at :cls:`werkzeug.wrappers.Request`.

    :param method: The method the request was made with, such as
        ``GET``.
    :param scheme: The URL scheme of the protocol the request used, such
        as ``https`` or ``wss``.
    :param server: The address of the server. ``(host, port)``,
        ``(path, None)`` for unix sockets, or ``None`` if not known.
    :param root_path: The prefix that the application is mounted under.
        This is prepended to generated URLs, but is not part of route
        matching.
    :param path: The path part of the URL after ``root_path``.
    :param query_string: The part of the URL after the "?".
    :param headers: The headers received with the request.
    :param remote_addr: The address of the client sending the request.

    .. versionchanged:: 3.0
        The ``charset``, ``url_charset``, and ``encoding_errors`` attributes
        were removed.

    .. versionadded:: 2.0
    """

    #: The class to use for :attr:`args`, :attr:`form`, and :attr:`files`.
    #:
    #: .. deprecated:: 3.2
    #:     Will be removed in Werkzeug 3.3. It will always be ``ImmutableMultiDict``.
    #:
    #: .. versionadded:: 0.6
    parameter_storage_class: None = None

    #: The class to use for parsed dict values, such as :attr:`cookies`.
    #:
    #: .. deprecated:: 3.2
    #:     Will be removed in Werkzeug 3.3. It will always be ``ImmutableMultiDict``.
    #:
    #: .. versionchanged:: 1.0.0
    #:     Changed to ``ImmutableMultiDict`` to support multiple values.
    #:
    #: .. versionadded:: 0.6
    dict_storage_class: None = None

    #: The class to use for parsed list values, such as :attr:`access_route`.
    #:
    #: .. deprecated:: 3.2
    #:     Will be removed in Werkzeug 3.3. It will always be ``Sequence``.
    #:
    #: .. versionadded:: 0.6
    list_storage_class: None = None

    user_agent_class: None = None
    """The class used and returned by the :attr:`user_agent` property to
    parse the header. Defaults to
    :class:`~werkzeug.user_agent.UserAgent`, which does no parsing. An
    extension can provide a subclass that uses a parser to provide other
    data.

    .. deprecated 3.2
        Will be removed in Werkzeug 3.3. ``user_agent`` is a string and can be
        parsed directly if needed.

    .. versionadded:: 2.0
    """

    #: Valid host names when handling requests. By default all hosts are
    #: trusted, which means that whatever the client says the host is
    #: will be accepted.
    #:
    #: Because ``Host`` and ``X-Forwarded-Host`` headers can be set to
    #: any value by a malicious client, it is recommended to either set
    #: this property or implement similar validation in the proxy (if
    #: the application is being run behind one).
    #:
    #: .. versionadded:: 0.9
    trusted_hosts: list[str] | None = None

    def __init__(
        self,
        method: str,
        scheme: str,
        server: tuple[str, int | None] | None,
        root_path: str,
        path: str,
        query_string: bytes,
        headers: Headers,
        remote_addr: str | None,
    ) -> None:
        #: The method the request was made with, such as ``GET``.
        self.method = method.upper()
        #: The URL scheme of the protocol the request used, such as
        #: ``https`` or ``wss``.
        self.scheme = scheme
        #: The address of the server. ``(host, port)``, ``(path, None)``
        #: for unix sockets, or ``None`` if not known.
        self.server = server
        #: The prefix that the application is mounted under, without a
        #: trailing slash. :attr:`path` comes after this.
        self.root_path = root_path.rstrip("/")
        #: The path part of the URL after :attr:`root_path`. This is the
        #: path used for routing within the application.
        self.path = "/" + path.lstrip("/")
        #: The part of the URL after the "?". This is the raw value, use
        #: :attr:`args` for the parsed values.
        self.query_string = query_string
        #: The headers received with the request.
        self.headers = headers
        #: The address of the client sending the request.
        self.remote_addr = remote_addr

    def __repr__(self) -> str:
        try:
            url = self.url
        except Exception as e:
            url = f"(invalid URL: {e})"

        return f"<{type(self).__name__} {url!r} [{self.method}]>"

    @cached_property
    def args(self) -> ImmutableMultiDict[str, str]:
        """The parsed URL query parameters (the ``?key=value&a=b`` part of a
        URL) as an :class:`ImmutableMultiDict`.

        .. versionchanged:: 2.3
            Invalid bytes remain percent encoded.
        """
        items = parse_qsl(
            self.query_string.decode(),
            keep_blank_values=True,
            errors="werkzeug.url_quote",
        )

        if self.parameter_storage_class is not None:
            import warnings

            warnings.warn(
                "Setting 'Request.parameter_storage_class' is deprecated and will be"
                " removed in Werkzeug 3.3. It will always be 'ImmutableMultiDict'.",
                DeprecationWarning,
                stacklevel=2,
            )
            return self.parameter_storage_class(items)

        return ImmutableMultiDict(items)

    @cached_property
    def access_route(self) -> cabc.Sequence[str]:
        """The route taken from the client to the application.

        This is ``X-Forwarded-For`` if it is set. Remember to only trust the
        last N values, where N is the number of servers setting this header in
        front of the application.

        Otherwise, this only contains :attr:`remote_addr`, or is empty.
        """
        if "X-Forwarded-For" in self.headers:
            items = tuple(parse_list_header(self.headers["X-Forwarded-For"]))
        elif self.remote_addr is not None:
            items = (self.remote_addr,)
        else:
            items = ()

        if self.list_storage_class is not None:
            import warnings

            warnings.warn(
                "Setting 'Request.list_storage_class' is deprecated and will be"
                " removed in Werkzeug 3.3. It will always be 'Sequence'.",
                DeprecationWarning,
                stacklevel=2,
            )
            return self.list_storage_class(items)

        return items

    @cached_property
    def full_path(self) -> str:
        """Requested path, including the query string."""
        return f"{self.path}?{self.query_string.decode()}"

    @property
    def is_secure(self) -> bool:
        """``True`` if the request was made with a secure protocol
        (HTTPS or WSS).
        """
        return self.scheme in {"https", "wss"}

    @cached_property
    def url(self) -> str:
        """The full request URL with the scheme, host, root path, path,
        and query string."""
        return get_current_url(
            self.scheme, self.host, self.root_path, self.path, self.query_string
        )

    @cached_property
    def base_url(self) -> str:
        """Like :attr:`url` but without the query string."""
        return get_current_url(self.scheme, self.host, self.root_path, self.path)

    @cached_property
    def root_url(self) -> str:
        """The request URL scheme, host, and root path. This is the root
        that the application is accessed from.
        """
        return get_current_url(self.scheme, self.host, self.root_path)

    @cached_property
    def host_url(self) -> str:
        """The request URL scheme and host only."""
        return get_current_url(self.scheme, self.host)

    @cached_property
    def host(self) -> str:
        """The host name the request was made to, including the port if
        it's non-standard. Validated with :attr:`trusted_hosts`.

        See :func:`.get_host` for a detailed explanation.
        """
        return get_host(
            self.scheme, self.headers.get("Host"), self.server, self.trusted_hosts
        )

    @cached_property
    def cookies(self) -> ImmutableMultiDict[str, str]:
        """A :class:`dict` with the contents of all cookies transmitted with
        the request."""
        wsgi_combined_cookie = ";".join(self.headers.getlist("Cookie"))
        kwargs: dict[str, t.Any] = {}

        if self.dict_storage_class is not None:
            kwargs["cls"] = self.dict_storage_class

        return parse_cookie(wsgi_combined_cookie, **kwargs)

    # Common Descriptors

    content_type = header_property[str](
        "Content-Type",
        doc="""The Content-Type entity-header field indicates the media
        type of the entity-body sent to the recipient or, in the case of
        the HEAD method, the media type that would have been sent had
        the request been a GET.""",
        read_only=True,
    )

    @cached_property
    def content_length(self) -> int | None:
        """The Content-Length entity-header field indicates the size of the
        entity-body in bytes or, in the case of the HEAD method, the size of
        the entity-body that would have been sent had the request been a
        GET.
        """
        return get_content_length(
            http_content_length=self.headers.get("Content-Length"),
            http_transfer_encoding=self.headers.get("Transfer-Encoding"),
        )

    content_encoding = header_property[str](
        "Content-Encoding",
        doc="""The Content-Encoding entity-header field is used as a
        modifier to the media-type. When present, its value indicates
        what additional content codings have been applied to the
        entity-body, and thus what decoding mechanisms must be applied
        in order to obtain the media-type referenced by the Content-Type
        header field.

        .. versionadded:: 0.9""",
        read_only=True,
    )

    @property
    def content_md5(self) -> str | None:
        """The ``Content-MD5`` header, an MD5 digest of the request body.

        .. deprecated:: 3.2
            The header has not been used for a long time. Will be removed
            in Werkzeug 3.3.

        .. versionadded:: 0.9
        """
        import warnings

        warnings.warn(
            "The 'content_md5' attribute is deprecated and will be removed in"
            " Werkzeug 3.3. The header has not been used for a long time.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.headers.get("Content-MD5")

    referrer = header_property[str](
        "Referer",
        doc="""The Referer[sic] request-header field allows the client
        to specify, for the server's benefit, the address (URI) of the
        resource from which the Request-URI was obtained (the
        "referrer", although the header field is misspelled).""",
        read_only=True,
    )
    date = header_property(
        "Date",
        None,
        parse_date,
        doc="""The Date general-header field represents the date and
        time at which the message was originated, having the same
        semantics as orig-date in RFC 822.

        .. versionchanged:: 2.0
            The datetime object is timezone-aware.
        """,
        read_only=True,
    )
    max_forwards = header_property(
        "Max-Forwards",
        None,
        int,
        doc="""The Max-Forwards request-header field provides a
        mechanism with the TRACE and OPTIONS methods to limit the number
        of proxies or gateways that can forward the request to the next
        inbound server.""",
        read_only=True,
    )

    def _parse_content_type(self) -> None:
        if not hasattr(self, "_parsed_content_type"):
            self._parsed_content_type = parse_options_header(self.content_type)

    @cached_property
    def mimetype(self) -> str:
        """The value from :attr:`content_type`, lowercase.
        For example, ``text/HTML; charset=utf-8`` becomes``text/html``.
        """
        self._parse_content_type()
        # Unlike content_type, this will be "" if the header isn't present,
        # instead of None. Checking ==/startswith/endswith is common for this,
        # so it's more convenient than None and essentially as accurate.
        return self._parsed_content_type[0].lower()

    @cached_property
    def mimetype_params(self) -> cabc.Mapping[str, str]:
        """The parameters from :attr:`content_type``. For example,
        ``text/html; charset=utf-8`` becomes ``{"charset": "utf-8"}``.
        """
        self._parse_content_type()
        return self._parsed_content_type[1]

    @property
    def pragma(self) -> HeaderSet:
        """The ``Pragma`` header.

        .. deprecated:: 3.2
            Use ``cache_control`` instead. Will be removed in Werkzeug 3.3.
        """
        import warnings

        warnings.warn(
            "The 'pragma' attribute is deprecated and will be removed in"
            " Werkzeug 3.3. Use 'cache_control' instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return HeaderSet.from_header(self.headers.get("Pragma"))

    # Accept

    @cached_property
    def accept_mimetypes(self) -> MIMEAccept:
        """List of content types (MIME types) the client supports, from the
        ``Accept`` header.
        """
        return MIMEAccept.from_header(self.headers.get("Accept"))

    @cached_property
    def accept_charsets(self) -> Accept:
        """Text encodings (charsets) the client accepts, from the
        ``Accept-Charset`` header.

        .. deprecated:: 3.2
            The header has not been used for a long time. Clients do not send
            it. Assume UTF-8. Will be removed in Werkzeug 3.3.
        """
        import warnings

        from ..datastructures.accept import _CharsetAccept

        warnings.warn(
            "The 'accept_charsets' attribute is deprecated and will be removed"
            " in Werkzeug 3.3. The header is not sent by browsers, and UTF-8 is"
            " assumed.",
            DeprecationWarning,
            stacklevel=2,
        )
        return _CharsetAccept.from_header(self.headers.get("Accept-Charset"))

    @cached_property
    def accept_encodings(self) -> Accept:
        """Content encodings (compression) the client accepts, from the
        ``Accept-Encoding`` header.
        """
        return Accept.from_header(self.headers.get("Accept-Encoding"))

    @cached_property
    def accept_languages(self) -> LanguageAccept:
        """Languages the client accepts, from the ``Accept-Language`` header.

        .. versionchanged 0.5
            Returns ``LanguageAccept`` instead of ``Accept``.
        """
        return LanguageAccept.from_header(self.headers.get("Accept-Language"))

    # ETag

    @cached_property
    def cache_control(self) -> RequestCacheControl:
        """A :class:`~werkzeug.datastructures.RequestCacheControl` object
        for the incoming cache control headers.
        """
        return RequestCacheControl.from_header(self.headers.get("Cache-Control"))

    @cached_property
    def if_match(self) -> ETags:
        """ETags parsed from the ``If-Match`` header."""
        return ETags.from_header(self.headers.get("If-Match"))

    @cached_property
    def if_none_match(self) -> ETags:
        """ETags parsed from the ``If-None-Match`` header."""
        return ETags.from_header(self.headers.get("If-None-Match"))

    @cached_property
    def if_modified_since(self) -> datetime | None:
        """The parsed `If-Modified-Since` header as a datetime object.

        .. versionchanged:: 2.0
            The datetime object is timezone-aware.
        """
        return parse_date(self.headers.get("If-Modified-Since"))

    @cached_property
    def if_unmodified_since(self) -> datetime | None:
        """The parsed `If-Unmodified-Since` header as a datetime object.

        .. versionchanged:: 2.0
            The datetime object is timezone-aware.
        """
        return parse_date(self.headers.get("If-Unmodified-Since"))

    @cached_property
    def if_range(self) -> IfRange:
        """The parsed ``If-Range`` header.

        .. versionchanged:: 3.2
            A weak ETag is discarded.

        .. versionchanged:: 2.0
            ``IfRange.date`` is timezone-aware.

        .. versionadded:: 0.7
        """
        return IfRange.from_header(self.headers.get("If-Range"))

    @cached_property
    def range(self) -> Range | None:
        """The parsed `Range` header.

        .. versionadded:: 0.7
        """
        return Range.from_header(self.headers.get("Range"))

    # User Agent

    @cached_property
    def user_agent(self) -> str:
        """The user agent. Use ``user_agent.string`` to get the header
        value. Set :attr:`user_agent_class` to a subclass of
        :class:`~werkzeug.user_agent.UserAgent` to provide parsing for
        the other properties or other extended data.

        .. versionchanged:: 3.2
            This is a string. ``UserAgent`` and ``user_agent_class`` are
            deprecated. Parse this directly if needed.

        .. versionchanged:: 2.1
            The built-in parser was removed. Set ``user_agent_class`` to a ``UserAgent``
            subclass to parse data from the string.
        """
        value = self.headers.get("User-Agent", "")

        if self.user_agent_class is not None:
            import warnings

            warnings.warn(
                "Setting 'Request.user_agent_class' is deprecated and will be"
                " removed in Werkzeug 3.3. 'user_agent' is a string and can be"
                " parsed directly if needed.",
                DeprecationWarning,
                stacklevel=2,
            )
            return self.user_agent_class(value)

        return _UserAgent(value)

    # Authorization

    @cached_property
    def authorization(self) -> Authorization | None:
        """The ``Authorization`` header parsed into an :class:`.Authorization` object.
        ``None`` if the header is not present.

        .. versionchanged:: 2.3
            :class:`Authorization` is no longer a ``dict``. The ``token`` attribute
            was added for auth schemes that use a token instead of parameters.
        """
        return Authorization.from_header(self.headers.get("Authorization"))

    # CORS

    origin = header_property[str](
        "Origin",
        doc=(
            "The host that the request originated from. Set"
            " :attr:`~CORSResponseMixin.access_control_allow_origin` on"
            " the response to indicate which origins are allowed."
        ),
        read_only=True,
    )

    access_control_request_headers = header_property[HeaderSet](
        "Access-Control-Request-Headers",
        load_func=HeaderSet.from_header,
        doc=(
            "Sent with a preflight request to indicate which headers"
            " will be sent with the cross origin request. Set"
            " :attr:`~CORSResponseMixin.access_control_allow_headers`"
            " on the response to indicate which headers are allowed."
        ),
        read_only=True,
    )

    access_control_request_method = header_property[str](
        "Access-Control-Request-Method",
        doc=(
            "Sent with a preflight request to indicate which method"
            " will be used for the cross origin request. Set"
            " :attr:`~CORSResponseMixin.access_control_allow_methods`"
            " on the response to indicate which methods are allowed."
        ),
        read_only=True,
    )

    sec_fetch_site = header_property[SecFetchSite](
        "Sec-Fetch-Site",
        load_func=SecFetchSite,
        read_only=True,
        doc="""Indicates the relationship between a request initiator's origin
        and the origin of the requested resource.

        Values are members of the :class:`.SecFetchSite` enum.

        .. versionadded:: 3.2
        """,
    )

    sec_fetch_mode = header_property[SecFetchMode](
        "Sec-Fetch-Mode",
        load_func=SecFetchMode,
        read_only=True,
        doc="""Distinguishes between requests originating from a user navigating
        between HTML pages, and requests to load images and other resources.

        Values are members of the :class:`.SecFetchMode` enum.

        .. versionadded:: 3.2
        """,
    )

    sec_fetch_user = header_property[bool](
        "Sec-Fetch-User",
        load_func=lambda value: value == "?1",
        read_only=True,
        doc="""Indicates whether a navigation request was originated by the user.

        .. versionadded:: 3.2
        """,
    )

    sec_fetch_dest = header_property[SecFetchDest](
        "Sec-Fetch-Dest",
        load_func=SecFetchDest,
        read_only=True,
        doc="""Indicates how the response to the request is expected to be used.

        Values are members of the :class:`.SecFetchDest` enum.

        .. versionadded:: 3.2
        """,
    )

    @property
    def is_json(self) -> bool:
        """Check if the mimetype indicates JSON data, either
        :mimetype:`application/json` or :mimetype:`application/*+json`.
        """
        mt = self.mimetype
        return (
            mt == "application/json"
            or mt.startswith("application/")
            and mt.endswith("+json")
        )
